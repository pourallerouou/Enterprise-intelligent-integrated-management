package com.smart.ecommerce.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceBackApplication.class, args);
	}

}
